<?php 
session_start();
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login | Farmket</title>
        <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
        .myAlert-top{
         position: fixed;
         top: 65px; 
         left:15%;
         width: 70%;
        }
        </style>
    </head>

    <body>
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="index.php">Farmket</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="content">
            <div class="container-fluid decor_bg" id="login-panel">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-primary" >
                            <div class="panel-heading">
                                <h4>LOGIN</h4>
                            </div>
                            <div class="panel-body">
                                <p class="text-warning"><i>Login to trade</i><p>
                                <form role="form" name="form2" method="post" action="" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <input type="email" class="form-control"  placeholder="Email" name="Email" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password" name="Password" required>
                                    </div>
                                    <button type="submit" name="submit1" class="btn btn-primary btn-block">Login</button><br><br>
                                </form><br/>
                            </div>
                            <div class="panel-footer"><p>Don't have an account? <a href="register.php">Register</a></p></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php 
		$query="select * from register";
		$result_set=mysqli_query($link,$query);
		$files_1=mysqli_fetch_all($result_set,MYSQLI_ASSOC);
		if(isset($_POST['submit1']))
		{
			$count=0;
			$result_set=mysqli_query($link,"select * from register where Email='$_POST[Email]'&& Password='$_POST[Password]'");
			$count=mysqli_num_rows($result_set);
			if($count==0)
			{
				?>
				<div class="myAlert-top alert alert-danger">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Login Failed!</strong> Invalid email-id or password.
</div>
				<?php 
			}
			else
			{
     		 $_SESSION['student']=$_POST['Email'];
     		 ?>
    		 <script type="text/javascript">
     			window.location="index1.php";
     		</script>
    		 <?php 
			}
		}
		?>
        <footer>
            <div class="container">
                <center>
                    <p>Copyright &copy; Farmket. All Rights Reserved  |  Contact Us: +91 90000 00000</p>	
                </center>
            </div>
        </footer>
    </body>
</html>