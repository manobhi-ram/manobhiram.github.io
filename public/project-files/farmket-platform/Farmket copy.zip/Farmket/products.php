<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Products | Farmket</title>
        <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="index1.php">Farmket</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href = "cart.php"><span class = "glyphicon glyphicon-shopping-cart"></span> Cart </a></li>
                        <li><a href = "settings.php"><span class = "glyphicon glyphicon-user"></span> Settings</a></li>
                        <li><a href = "logout.php"><span class = "glyphicon glyphicon-log-in"></span> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="container " id="content">

            <!-- Jumbotron Header -->
            <div class="jumbotron home-spacer" id="products-jumbotron">
                <h1 align="center">Welcome to our Farmket</h1>
                <p align="center">We have the Market place, farming essentials and slots of mills/godowns/coldstorages for you.<br> No need to hunt around, we have all in one place.</p>

            </div>
            <hr>
             <h2 align="center">Markets</h2>
            <div class="horizontal-scrollable">
            <div class="row text-center" id="markets">
              
                <div class="col-md-3 col-sm-6 home-feature ">
                  
                    <div class="thumbnail">
                        <img src="img/m1.jpg" alt="">
                        <div class="caption">
                            <h3>Market 1 </h3>
                            <p>Price for your crop: Rs.36000.00 </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Trade Now</a></p>
                        </div>
                    </div>
                </div>
             
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/m2.jpg" alt="">
                        <div class="caption">
                            <h3>Market 2</h3>
                            <p>Price for your crop: Rs. 40,000.00 </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Trade Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/m3.jpg" alt="">
                        <div class="caption">
                            <h3>Market 3</h3>
                            <p>Price for your crop: Rs. 50000.00</p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Trade Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/m4.jpg" alt="">
                        <div class="caption">
                            <h3>Market 4</h3>
                            <p>Price for your crop: Rs. 50000.00</p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Trade Now</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/m5.jpg" alt="">
                        <div class="caption">
                            <h3>Market 5</h3>
                            <p>Price for your crop: Rs. 50000.00</p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Trade Now</a></p>
                        </div>
                    </div>
                </div>
              
            </div>
         </div>
             <h2 align="center">Seeds</h2>
            <div class="horizontal-scrollable">
            <div class="row text-center" id="seeds">
              
                <div class="col-md-3 col-sm-6 home-feature ">
                  
                    <div class="thumbnail">
                        <img src="img/s1.jpg" alt="">
                        <div class="caption">
                            <h3>Cotton seeds</h3>
                            <p>Price : Rs.  </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
             
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/s2.jpg" alt="">
                        <div class="caption">
                            <h3>Chilly seeds</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/s3.jpg" alt="">
                        <div class="caption">
                            <h3>Paddy seeds</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block"> Shop Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/s4.jpg" alt="">
                        <div class="caption">
                            <h3>Vegetable seeds</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/s5.jpg" alt="">
                        <div class="caption">
                            <h3>Food grains</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
              
            </div>
         </div>
             <h2 align="center">Fertilizers & other chemicals</h2>
            <div class="horizontal-scrollable">
            <div class="row text-center" id="chemicals">
              
                <div class="col-md-3 col-sm-6 home-feature ">
                  
                    <div class="thumbnail">
                        <img src="img/c1.jpg" alt="">
                        <div class="caption">
                            <h3>Chemical 1 </h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
             
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/c2.jpg" alt="">
                        <div class="caption">
                            <h3>Chemical 2</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/c3.jpg" alt="">
                        <div class="caption">
                            <h3>Chemical 3</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/c4.jpg" alt="">
                        <div class="caption">
                            <h3>Chemical 4</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/c5.jpg" alt="">
                        <div class="caption">
                            <h3>Chemical 5</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Shop Now</a></p>
                        </div>
                    </div>
                </div>
              
            </div>
         </div>
             <h2 align="center">Godowns & Cold storages</h2>
            <div class="horizontal-scrollable">
            <div class="row text-center" id="c&d">
              
                <div class="col-md-3 col-sm-6 home-feature ">
                  
                    <div class="thumbnail">
                        <img src="img/g1.jpg" alt="">
                        <div class="caption">
                            <h3>Area 1 </h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
             
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/g2.jpg" alt="">
                        <div class="caption">
                            <h3>Area 2</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/g3.jpg" alt="">
                        <div class="caption">
                            <h3>Area 3</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/g4.jpg" alt="">
                        <div class="caption">
                            <h3>Area 4</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/g5.jpg" alt="">
                        <div class="caption">
                            <h3>Area 5</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
              
            </div>
         </div>
             <h2 align="center">Mills</h2>
            <div class="horizontal-scrollable">
            <div class="row text-center" id="mills">
              
                <div class="col-md-3 col-sm-6 home-feature ">
                  
                    <div class="thumbnail">
                        <img src="img/l1.jpg" alt="">
                        <div class="caption">
                            <h3>Mill 1 </h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
             
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/l2.jpg" alt="">
                        <div class="caption">
                            <h3>Mill 2</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/l3.jpg" alt="">
                        <div class="caption">
                            <h3>Mill 3</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/l4.jpg" alt="">
                        <div class="caption">
                            <h3>Mill 4</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/l5.jpg" alt="">
                        <div class="caption">
                            <h3>Mill 5</h3>
                            <p>Price : Rs. </p>
                            <p><a href="login.html" role="button" class="btn btn-primary btn-block">Book Now</a></p>
                        </div>
                    </div>
                </div>
              
            </div>
         </div>
        <footer>
            <div class="container">
                <center>
                    <p>Copyright &copy; Farmket. All Rights Reserved  |  Contact Us: +91 90000 00000</p>	
                </center>
            </div>
        </footer>
    </body>
</html>
