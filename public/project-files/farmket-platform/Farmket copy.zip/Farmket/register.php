<?php
session_start(); 
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Signup | Farmket</title>
        <link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
        .myAlert-top{
         position: fixed;
         top: 65px; 
         left:20%;
         width: 55%;
        }
        </style>
    </head>
    <body>
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="index.php">Farmket</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <div class="panel panel-primary" >
                            <div class="panel-heading">
                                <h4>Sign Up</h4>
                            </div>
                            <div class="panel-body">
                        <form  action="" method="post" name="form2" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="First name" name="F_name"  required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Last name" name="L_name"  required>
                            </div>
                            <div class="form-group">
                                <label id="gender">Gender:&nbsp;</label>
                                <input type="radio" name="Gender" value="Male" /><span>&nbsp; Male</span>
                                <input type="radio" name="Gender" value="Female" /><span>&nbsp; Female</span>
                            </div>
                            <div class="form-group">
                                <label id="F_type">User type:&nbsp;</label><br>
                                <input type="radio" name="Farmer_type" value="Permanant farmer" /><span>&nbsp; Permanant farmer</span><br>
                                <input type="radio" name="Farmer_type" value="temporary farmer" /><span>&nbsp; tenant farmer</span><br>
                                <input type="radio" name="Farmer_type" value="Not farmer" /><span>&nbsp; Non-farmer</span>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Email"  name="Email" required>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password" name="Password" required>
                            </div>
                            <div class="form-group">
                                <input type="number" class="form-control"  placeholder="Contact" maxlength="10" size="10" name="Mobile_number" required>
                            </div>
                            <div class="form-group">
                                <input  type="text" class="form-control"  placeholder="City" name="City" required>
                            </div>
                            <div class="form-group">
                                <input  type="text" class="form-control"  placeholder="Address" name="Address" required>
                            </div>
                            <div class="form-group">
                               <select name="District">
                                   <option selected="" value="Default">(Please select a District)</option>
                                   <option value="Ananthapur">Ananthapur</option>
                                   <option value="Chittore">Chittore</option>
                                   <option value="East Godavari">East Godavari</option>
                                   <option value="Guntur">Guntur</option>
                                   <option value="Kadapa">Kadapa</option>
                                   <option value="Krishna">Krishna</option>
                                   <option value="Kurnool">Kurnool</option>
                                   <option value="Nellore">Nellore</option>
                                   <option value="Prakasam">Prakasam</option>
                                   <option value="Srikakulam">Srikakulam</option>
                                   <option value="Vishakapatnam">Vishakapatnam</option>
                                   <option value="Vijayanagaram">Vijayanagaram</option>
                                   <option value="West Godavari">West Godavari</option>
                               </select>
                            </div>
                            <div>
                                <input type="checkbox" name="en" value="en" checked /><span>&nbsp; Accept terms and conditions</span>
                             </div><br>
                            <div>
                            <button type="submit" name="submit2" class="btn btn-primary btn-block">Sign Up now</button>
                            </div>
                        </form>
                      </div></div>
                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div class="container">
                <center>
                    <p>Copyright &copy; Farmket. All Rights Reserved  |  Contact Us: +91 90000 00000</p>	
                </center>
            </div>
        </footer>
    </body>
</html>
<?php 
$query="select * from register";
$result_set=mysqli_query($link,$query);
$files_1=mysqli_fetch_all($result_set,MYSQLI_ASSOC);
if(isset($_POST['submit2']))
{
	$sql="insert into register(F_name,L_name,Gender,Farmer_type,Email,Password,Mobile_number,City,Address,District) values('$_POST[F_name]','$_POST[L_name]','$_POST[Gender]','$_POST[Farmer_type]','$_POST[Email]','$_POST[Password]','$_POST[Mobile_number]','$_POST[City]','$_POST[Address]','$_POST[District]')";
	if(mysqli_query($link,$sql))
	{
		echo "<script>alert('Registration successful');</script>";
        ?>
        <script type="text/javascript">
                window.location="index1.php";
            </script>
<?php
	}
	else
	{
        ?>
		<div class="myAlert-top alert alert-danger">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Registration Failed!</strong> Given email address may be registered already.
</div>
<?php
	}
}
?>